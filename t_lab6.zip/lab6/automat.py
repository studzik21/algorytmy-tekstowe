from queue import Queue
from PIL import Image
import time
class Node:
    def __init__(self):
        self.state = 0
        self.children = {}
        self.fail =None


def kmp_string_matching(text,pattern,pi,idx):
    result_kmp = []
    q = 0
    for i in range(0, len(text)):
        while (q > 0 and pattern[q] != text[i]):
            q = pi[q - 1]
        if (pattern[q] == text[i]):
            q = q + 1
        if (q == len(pattern)):
            result_kmp.append((i + 1 - q,idx))
            q = pi[q - 1]
    return result_kmp


def prefix_function(pattern):
    pi = [0]
    k = 0
    for q in range(1, len(pattern)):
        while (k > 0 and pattern[k] != pattern[q]):
            k = pi[k - 1]
        if (pattern[k] == pattern[q]):
            k = k + 1
        pi.append(k)

    return pi



class Tree:
    def __init__(self,pattern):
        self.final_states = []
        self.trie= Node()
        self.state = self.trie
        self.pattern = pattern

        self.current_node =None
        self.trie.state= 0

        current_state = 1
        alphabet = set()
        m = len(pattern)

        for i in range(m):
            tmp= self.trie
            for j in range(len(pattern[i])):
                if pattern[i][j] not in tmp.children.keys():
                    alphabet.add(pattern[i][j])
                    tmp_child= Node()
                    tmp.children[pattern[i][j]]=tmp_child
                    tmp_child.state = current_state
                    current_state+=1
                tmp=tmp.children[pattern[i][j]]

        q = Queue()
        for c in self.trie.children.keys():
            self.trie.children[c].fail = self.trie
            q.put(self.trie.children[c])


        for l in alphabet:
            if l not in self.trie.children:
                self.trie.children[l] =self.trie  # jesli nie ma takiej literki w poczatku wzorca idziemy do siebie

        while not q.empty():
            node = q.get()
            for l in alphabet:
                if l in node.children.keys():
                    next_node = node.children[l]
                    q.put(next_node)
                    tmp = node.fail
                    while l not in tmp.children.keys():
                        tmp = tmp.fail
                    next_node.fail = tmp.children[l]


        for i in range(m):
            tmp = self.trie
            for l in pattern[i]:
                tmp=tmp.children[l]
            self.final_states.append(tmp.state)

    def find_char(self,letter):
        while letter not in self.current_node.children.keys():
            self.current_node = self.current_node.fail
            if self.current_node is None:
                self.current_node= self.trie
                return self.current_node
        self.current_node = self.current_node.children[letter]
        return self.current_node

    def find(self,text):
        result =[]
        length = len(text[0])
        table = []

        for line in text:
            length=max(length,len(line))
            table.append([])


        for i in range(len(text)):
            self.current_node = self.trie
            for j in range(length):
                if(j<len(text[i])):
                    self.current_node = self.find_char(text[i][j])
                    table[i].append(self.current_node.state)
                else:
                    table[i].append(0)

        pi = prefix_function(self.final_states)
        x=[0 for i in range(len(text))]
        for i in range(length):
            for j in range(len(text)):
                x[j]=table[j][i]

            res=kmp_string_matching(x,self.final_states,pi,i)
            if len(res)>0:
                for el in res:
                    result.append(el)

        return result


def zad2():
    file=open('haystack.txt','r')
    data = file.readlines()
    for i in range(len(data)):
        data[i]=list(data[i])
    alphabet = set()

    for r in data:
        for l in r:
            alphabet.add(l)


    for l in alphabet:
        X = Tree([l, l])
        result = X.find(data)
        if len(result)>0:
            print(l)
            print(result)


def zad3():
    file = open('haystack.txt', 'r')
    data = file.readlines()
    for i in range(len(data)):
        data[i] = list(data[i])
    X = Tree(["t h", "t h"])
    result = X.find(data)
    print("t h , t h")
    print(result)

    X = Tree(["th", "th"])
    result = X.find(data)
    print("th , th")
    print(result)



def load_img(name):
    img = Image.open(name)
    pixels =img.load()
    table = []

    for i in range(img.height):
        row=[]
        for j in range(img.width):
            row.append(pixels[j,i][0])
        table.append(row)
    return table


def find_letter(letter_name):
    letter = load_img(letter_name)

    text = load_img('haystack.png')
    T = Tree(letter)
    res = T.find(text)
    print(letter_name)
    print(len(res))

def zad4():
    find_letter("p.png")
    find_letter("i.png")
    find_letter("c.png")
    find_letter("x.png")



def zad5():
    pattern=load_img('pattern.png')
    text=load_img('haystack.png')
    T=Tree(pattern)
    res=T.find(text)
    print(len(res))
    print(res)


def zad6():
    small_pattern = ["Patrk","Sebastian","Grzegorz"]
    medium_pattern = ["dictionaries is illustrated by spelling checkers.",
                      "reports the words in its input t h a t are not st",
                      "approach does not yield a pertinent checker, b u ",
                      " typing errors. T h e lexicon used by spell contain",
                      "tries stored within less t h a n 60 kilobytes of r"]

    big_pattern =["One of the simplest and n a t u r a l types of information representation is by means",
        "of written texts. This type of d a t a is characterized by t h e fact t h a t it can",
        "be written down as a long sequence of characters. Such linear a sequence",
        "is called a text. T h e texts are central in word processing systems, which",
        "provide facilities for t h e manipulation of texts. Such systems usually process",
        "objects t h a t are quite large. For example, this book probably contains more",
        "t h a n a million characters. Text algorithms occur in many areas of science and",
        "information processing. Many text editors and programming languages have",
        "facilities for processing texts. In biology, text algorithms arise in the study",
        "of molecular sequences. T h e complexity of text algorithms is also one of t h e",
        "central and most studied problems in theoretical computer science. It could",
        "be said t h a t it is the domain in which practice and theory are very close to",
        "each other.",
        "T h e basic textual problem in stringology is called pattern matching. It is",
        "used to access information and, no doubt, at this moment m a n y computers",
        "are solving this problem as a frequently used operation in some application",
        "system. P a t t e r n matching is comparable in this sense to sorting, or to basic",
        "arithmetic operations.",
        "Consider the problem of a reader of the French dictionary ",
        "who wants all entries related to the n a m e Marie-Curie-Sklodowska. This is",
        "a n example of a p a t t e r n matching problem, or string matching. In this case,",
        "the n a m e Marie-Curie-Sklodowska is the p a t t e r n . Generally we m a y want to",
        "find a string called a pattern of length m inside a text of length n, where n is",
        "greater t h a n m. T h e p a t t e r n can be described in a more complex way to denote",
        "a set of strings and not just a single word. In many cases n is very large. In",
        "genetics the p a t t e r n can correspond to a gene t h a t can be very long; in image"]
    start = time.time()
    T = Tree(small_pattern)
    print("small pattern time %f", time.time() - start)

    start = time.time()
    T = Tree(medium_pattern)
    print("medium pattern time %f", time.time() - start)

    start = time.time()
    T = Tree(big_pattern)
    print("big pattern time %f", time.time() - start)


def search_in_divided_text(parts, text,T):
    n=len(text)//parts
    start = time.time()
    for i in range(parts):
        T.find(text[i*n:(i+1)*n-1])
    print("%d parts time: %f" % (parts,time.time() - start))



def zad7():
    file = open('haystack2.txt', 'r')
    data = file.readlines()
    for i in range(len(data)):
        data[i] = list(data[i])
    T = Tree(["p a t t e r n"])
    start = time.time()
    T.find(data)
    print("without dividing time:",time.time() - start)
    search_in_divided_text(2,data,T)
    search_in_divided_text(4,data,T)
    search_in_divided_text(8,data,T)

#zad2()
#zad3()
#zad4()
#zad5()
#zad6()
#zad7()