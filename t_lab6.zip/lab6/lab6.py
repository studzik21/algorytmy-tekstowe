import re

def transition_table(pattern):
    alphabet = set()
    result = []
    for a in pattern:
        alphabet.add(a)

    for q in range(0, len(pattern) + 1):
        result.append({})
        for a in alphabet:
            k = min(len(pattern), q + 1)  # ostatni stan lub następny stan
            while True:
                if (re.search(f"{pattern[:k]}$", pattern[:q] + a)):  # suffix
                    break
                k = k - 1
            result[q][a] = k
    return result





def fa_string_matching(text, pattern, delta):
    result_fa = []
    q = 0
    for s in range(0, len(text)):
        if text[s] in delta[q]:
            q = delta[q][text[s]]
            if q == len(pattern):
                result_fa.append(s + 1 - q)
                # s + 1 - ponieważ przeczytaliśmy znak o indeksie s,
                # więc przesunięcie jest po tym znaku
        else:
            q = 0
    return result_fa

