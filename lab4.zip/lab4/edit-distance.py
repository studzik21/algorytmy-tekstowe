from bisect import bisect

import numpy as np
from spacy.language import Language
from spacy.tokenizer import Tokenizer
from spacy.vocab import Vocab
from random import random


def delta(a, b):
    if a == b:
        return 0
    else:
        return 1



def create_edit_table(x, y):
    edit_table = np.empty((len(x) + 1, len(y) + 1))
    for i in range(len(x) + 1):
        edit_table[i, 0] = i
    for j in range(len(y) + 1):
        edit_table[0, j] = j

    for i in range(len(x)):
        k = i + 1
        for j in range(len(y)):
            l = j + 1
            edit_table[k, l] = min(edit_table[k - 1, l] + 1, edit_table[k, l - 1] + 1,
                                   edit_table[k - 1, l - 1] + delta(x[i], y[j]))
    return edit_table


def edit_distance(x, y):
    edit_table = create_edit_table(x, y)
    return edit_table[(len(x), len(y))]

def edit_distance_visualisation(x,y):
    edit_table = create_edit_table(x, y)
    res = ""
    k = len(x)
    l = len(y)
    while k != 0 or l != 0:

        if k == 0:
            res += "+" + y[l - 1] + "+"
            l -= 1
        elif l == 0:
            res += "*-*"
            k -= 1
        else:
            m = min(edit_table[k - 1, l] + 1, edit_table[k, l - 1] + 1,
                    edit_table[k - 1, l - 1] + delta(x[k - 1], y[l - 1]))
            if m == edit_table[k - 1, l - 1] + delta(x[k - 1], y[l - 1]):
                if x[k - 1] == y[l - 1]:
                    res +="|"+x[k - 1]+"|"
                else:
                    res += "*" + y[l - 1] + "*"
                k -= 1
                l -= 1

            elif m == edit_table[k, l - 1] + 1:
                res += "+" + y[l - 1] + "+"
                l -= 1
            else:
                res += "*-*"
                k -= 1
    tmp_res=""
    for i in range(len(res) - 1, -1, -1):
        tmp_res+=res[i]

    res=tmp_res
    for i in range(len(x)):
        print(y[:i]+res[3*(i):3*(i+1)]+x[i+1:])

def edit_distanc_vis(k, l, word, idx, x, y, edit_table):
    if (k != 0 or l != 0):
        if k == 0:
            word, idx = edit_distanc_vis(k, l - 1, word, idx, x, y, edit_table)
            print(word[:idx] + "+" + y[l - 1] + "+" + word[idx:])
            return word[:idx] + y[l - 1] + word[idx:], idx + 1
        elif l == 0:
            word, idx = edit_distanc_vis(k - 1, l, word, idx, x, y, edit_table)
            print(word[:idx] + "+" + y[l - 1] + "+" + word[idx:])
            return word[:idx] + "-" + word[idx:], idx
        else:
            m = min(edit_table[k - 1, l] + 1, edit_table[k, l - 1] + 1,
                    edit_table[k - 1, l - 1] + delta(x[k - 1], y[l - 1]))

            if m == edit_table[k - 1, l - 1] + delta(x[k - 1], y[l - 1]):
                word, idx = edit_distanc_vis(k - 1, l - 1, word, idx, x, y, edit_table)
                if x[k - 1] == y[l - 1]:
                    #print(word)
                    return word, idx + 1
                else:
                    print(word[:idx] + "*" + y[l - 1] + "*" + word[idx+1:])
                    return word[:idx] + y[l - 1] + word[idx+1:],idx+1


            elif m == edit_table[k, l - 1] + 1:
                word, idx = edit_distanc_vis(k, l - 1, word, idx, x, y, edit_table)
                print(word[:idx] + "+" + y[l - 1] + "+" + word[idx:])
                return word[:idx] + y[l - 1] + word[idx:], idx + 1
            else:
                word, idx = edit_distanc_vis(k - 1, l, word, idx, x, y, edit_table)
                print(word[:idx] + "-" + word[idx+1:])
                return word[:idx]  + word[idx+1:], idx

    else:
        print(word)
        return word,idx


def lcs(x,y):
    return (len(x)+len(y)-edit_distance(x,y))/2  # tutaj delta musi być 0-2



def lcs2(x, y):
    edit_table = create_edit_table(x, y)
    res = 0
    k = len(x)
    l = len(y)
    while k != 0 or l != 0:

        if k == 0:
            break
        elif l == 0:
            break
        else:
            m = min(edit_table[k - 1, l] + 1, edit_table[k, l - 1] + 1,
                    edit_table[k - 1, l - 1] + delta(x[k - 1], y[l - 1]))
            if m == edit_table[k - 1, l - 1] + delta(x[k - 1], y[l - 1]):
                if x[k - 1] == y[l - 1]:
                    res += 1

                k -= 1
                l -= 1

            elif m == edit_table[k, l - 1] + 1:
                l -= 1
            else:
                k -= 1

    return res

def lcs3(x, y):
    ranges = [len(y)]
    y_letters = list(y)
    for i in range(len(x)):
        positions = [j for j, l in enumerate(y_letters) if l == x[i]]
        positions.reverse()
        for p in positions:
            k = bisect(ranges, p)
            if k == bisect(ranges, p - 1):
                if k < len(ranges) - 1:
                    ranges[k] = p
                else:
                    ranges[k:k] = [p]
    return len(ranges) - 1


def read_and_remove_tokens(file_name):
    f=open(file_name,"r",encoding='utf-8')
    data=f.read()

    f.close()
    vocab = Language(Vocab()).vocab
    tokenizer = Tokenizer(vocab)
    tokens=tokenizer(data)
    tmp1=[]
    tmp2=[]
    for t in tokens:
        if random()< 0.97:
            tmp1.append(t)
        if random()< 0.97:
            tmp2.append(t)
    data1=tmp1
    data2=tmp2

    f1=open("data1.txt","w+")
    f2=open("data2.txt","w+")
    for t in data1:
        f1.write(t.text_with_ws)
    for t in data2:
        f2.write(t.text_with_ws)
    f1.seek(0)
    f2.seek(0)


    A=f1.read()
    B=f2.read()
    f1.close()
    f2.close()

    print("length romeo-i-julia-700.txt: "+str(len(data)))
    print("length A: "+str(len(A)))
    print("length B: "+str(len(B)))
    print("lcs(A,B): "+ str(lcs3(A,B)))

def diff():
    f1 = open("data1.txt", "r")
    f2 = open("data2.txt", "r")
    data1=f1.read().split('\n')
    data2=f2.read().split('\n')

    arr = [[0 for i in range(len(data2)+1) ]for j in range(len(data1)+1)]

    for i in range(len(data1)+1):
        for j in range(len(data2)+1):
            if i==0 or j==0:
                arr[i][j]=0
            elif lcs3(data1[i-1],data2[j-1]) == max(len(data1[i-1]),len(data2[j-1])):
                arr[i][j]= arr[i-1][j-1] +1
            else:
                arr[i][j]=max(arr[i-1][j],arr[i][j-1])

    result=[]
    i=len(data1)-1
    j=len(data2)-1

    while i>=0 and j>=0:
        if data1[i]==data2[j]:
            i-=1
            j-= 1
        elif arr[i][j-1] >= arr[i-1][j]:
            result.append(f"> {j} {data2[j]}")
            j-=1
        elif arr[i][j-1] < arr[i-1][j]:
            result.append(f"< {i} {data1[i]}")
            i -= 1
    while j >= 0:
        result.append(f"> {j} {data2[j]}")
        j -= 1
    while i >= 0:
        result.append(f"< {i} {data1[i]}")
        i -= 1
    result.reverse()
    for line in result:
        print(line)


def test(x,y):
    print(x,end=" - ")
    print(y)
    print("edit distance: ", end="")
    print(edit_distance(x, y))
    print("lcs: ", end="")
    print(lcs3(x,y))
    edit_distanc_vis(len(x), len(y), x, 0, x, y, create_edit_table(x, y))
    print()

# test("los","kloc")
# test("Łódź","Lodz")
# test("kwintesencja","quintessence")
# test("ATGAATCTTACCGCCTCG", "ATGAGGCTCTGGCCCCTG")


read_and_remove_tokens("romeo-i-julia-700.txt")
#diff()