import os
import time
from bitarray import bitarray


class Node:

    def __init__(self, letter, weight, left=None, right=None, idx=0, parent=None):
        self.letter = letter
        self.weight = weight
        self.leftChild = left
        self.rightChild = right
        self.idx = idx
        self.parent = parent

    def increment(self, nodes):
        if self.parent == None:
            self.weight += 1
            return
        nodes.sort(key=lambda n: n.idx)

        for i in range(len(nodes)):
            if nodes[i] == self:
                self.weight += 1
                self.parent.increment(nodes)
                return
            if nodes[i].weight == self.weight:

                self_tmp = self
                other_tmp = nodes[i]
                parent_self = self.parent
                parent_other = other_tmp.parent

                if parent_other == parent_self:
                    parent_self.leftChild, parent_self.rightChild = parent_self.rightChild, parent_self.leftChild
                    self.weight += 1
                    self.idx, nodes[i].idx = nodes[i].idx, self.idx
                    self.parent.increment(nodes)
                    return

                if parent_self.leftChild == self_tmp:
                    parent_self.leftChild = other_tmp
                    nodes[i].parent = parent_self
                else:
                    parent_self.rightChild = other_tmp
                    nodes[i].parent = parent_self

                if parent_other.leftChild == other_tmp:
                    parent_other.leftChild = self_tmp
                    self.parent = parent_other
                else:
                    parent_other.rightChild = self_tmp
                    self.parent = parent_other

                self.weight += 1
                self.idx, nodes[i].idx = nodes[i].idx, self.idx

                self.parent.increment(nodes)
                return


def huffman(letter_counts):
    nodes = []
    for a, weight in letter_counts.items():
        nodes.append(Node(a, weight))
    internal_nodes = []
    leafs = sorted(nodes, key=lambda n: n.weight)
    while len(leafs) + len(internal_nodes) > 1:
        element_1, element_2 = None, None
        if len(leafs) == 0:
            element_1 = internal_nodes.pop(0)
            element_2 = internal_nodes.pop(0)
        elif len(internal_nodes) == 0:
            element_1 = leafs.pop(0)
            element_2 = leafs.pop(0)

        elif len(leafs) > 1 and len(internal_nodes) > 1:
            if leafs[0].weight <= internal_nodes[0].weight:
                element_1 = leafs.pop(0)
                if leafs[0].weight <= internal_nodes[0].weight:
                    element_2 = leafs.pop(0)
                else:
                    element_2 = internal_nodes.pop(0)
            else:
                element_1 = internal_nodes.pop(0)
                if leafs[0].weight <= internal_nodes[0].weight:
                    element_2 = leafs.pop(0)
                else:
                    element_2 = internal_nodes.pop(0)

        elif leafs[0].weight <= internal_nodes[0].weight:
            element_1 = leafs.pop(0)
            if len(leafs) > 0 and leafs[0].weight <= internal_nodes[0].weight:
                element_2 = leafs.pop(0)
            else:
                element_2 = internal_nodes.pop(0)
        else:
            element_1 = internal_nodes.pop(0)
            if len(internal_nodes) > 0 and leafs[0].weight > internal_nodes[0].weight:
                element_2 = internal_nodes.pop(0)
            else:
                element_2 = leafs.pop(0)

        internal_nodes.append(Node(None, element_1.weight + element_2.weight, element_1, element_2))
    return internal_nodes[0]


def print_codes(node, code):
    if (node.letter != None):
        print(node.letter + ": " + code)
    else:
        print_codes(node.leftChild, code + "0")
        print_codes(node.rightChild, code + "1")



def huffman_code(node, code, huffman_dict):
    if (node.letter != None):
        huffman_dict[node.letter] = code
    else:
        huffman_code(node.leftChild, code + "0", huffman_dict)
        huffman_code(node.rightChild, code + "1", huffman_dict)


def adaptive_huffman_start(text):
    nodes = []
    nodes_dict = {}
    root = Node("#", weight=0, idx=0, parent=None)

    nodes_dict["#"] = root
    nodes.append(root)

    for letter in text:
        if letter in nodes_dict.keys():
            node = nodes_dict.get(letter)
            node.increment(nodes)
        else:

            updated_node = nodes_dict.get("#")
            updated_node.letter = None
            updated_node.weight = 1
            node = Node(letter, weight=1, idx=updated_node.idx + 1, parent=updated_node)
            nodes_dict[letter] = node
            nodes.append(node)
            zero_node = Node("#", 0, idx=updated_node.idx + 2, parent=updated_node)
            nodes.append(zero_node)
            nodes_dict["#"] = zero_node
            updated_node.leftChild = zero_node
            updated_node.rightChild = node
            if updated_node.parent != None:
                updated_node.parent.increment(nodes)

    return root, nodes, nodes_dict


def adaptive_hufman(text, save_file_name, alphabet):
    file = open(save_file_name, "wb")
    bits = bitarray()
    root, nodes, nodes_dict = adaptive_huffman_start(alphabet)

    for letter in text:
        current_dict = {}
        huffman_code(root, "", current_dict)
        bits += current_dict.get(letter)

        if letter in nodes_dict.keys():
            node = nodes_dict.get(letter)
            node.increment(nodes)

    bits.tofile(file)
    file.close()
    return len(bits)


def adaptive_hufman_decode(data_file, save_file_name, alphabet, n):
    file = open(data_file, "rb")
    save_file = open(save_file_name, "w", encoding='utf-8')
    text = bitarray()
    text.fromfile(file)
    text = text[:n]
    root, nodes, nodes_dict = adaptive_huffman_start(alphabet)
    current_dict = {}
    huffman_code(root, "", current_dict)
    i = 0
    current_text = ""

    while i < len(text):
        node = root
        while node.letter == None:
            if text[i]:
                node = node.rightChild
            else:
                node = node.leftChild
            i += 1
        save_file.write(node.letter)
        current_text = ""
        n = nodes_dict.get(node.letter)
        n.increment(nodes)
        current_dict = {}
        huffman_code(root, "", current_dict)


    file.close()
    save_file.close()


def letter_counts(text):
    letter_c = {}
    for letter in text:
        if letter in letter_c.keys():
            letter_c[letter] = letter_c[letter] + 1
        else:
            letter_c[letter] = 1
    return letter_c


def encode(text, save_file_name, huffman_dict):
    file = open(save_file_name, "wb")
    bits = bitarray()
    bits.frombytes(len(huffman_dict).to_bytes(4, byteorder="big", signed=False))
    for key, val in huffman_dict.items():
        k = bitarray()
        k.frombytes(key.encode())
        s = bitarray()
        s.frombytes(len(k).to_bytes(4, byteorder="big", signed=False))
        l = bitarray()
        l.frombytes(len(val).to_bytes(4, byteorder="big", signed=False))
        v = bitarray(val)

        bits += s + k + l + v

    for letter in text:
        bits += huffman_dict.get(letter)
    bits.tofile(file)
    file.close()
    return len(bits)


def decode_help(save_file_name, dict, text):
    save_f = open(save_file_name, "w", encoding='utf-8')
    current = ''

    for l in text:
        if l:
            l = '1'
        else:
            l = '0'
        current += l
        if current in dict.keys():
            save_f.write(dict.get(current))
            current = ""
    save_f.close()


def decode(file_name, save_file, n):
    plik = open(file_name, "rb")
    text = bitarray()
    text.fromfile(plik)
    text = text[:n]
    new_dict = {}
    b = text[:32]
    dict_len = int.from_bytes(text[:32], byteorder="big")
    text = text[32:]
    i = 0
    while i < dict_len:
        s = int.from_bytes(text[:32], byteorder="big")
        text = text[32:]

        val = text[:s].tobytes().decode()
        text = text[s:]

        i += 1
        l = int.from_bytes(text[:32], byteorder="big")
        text = text[32:]
        key = ""
        for j in range(l):
            if text[j]:
                key += "1"
            else:
                key += "0"

        text = text[l:]
        new_dict[key] = val

    decode_help(save_file, new_dict, text)
    plik.close()


def test(data_file_name):
    print(data_file_name)
    data_file = open(data_file_name, "r", encoding='utf-8')
    compresed_huffman = data_file_name[:len(data_file_name) - 3] + "_huffman.txt"
    compresed_adaptive = data_file_name[:len(data_file_name) - 3] + "_adaptive.txt"
    decompresed_huffman = data_file_name[:len(data_file_name) - 3] + "_huffman_decompresed.txt"
    decompresed_adaptive = data_file_name[:len(data_file_name) - 3] + "_adaptive_decompresed.txt"
    data = data_file.read()
    data_file.close()
    print("Huffman:")
    start = time.time()
    huf = huffman(letter_counts(data))
    huf_dixt = {}
    huffman_code(huf, "", huf_dixt)
    n = encode(data, compresed_huffman, huf_dixt)
    print("huffman encode time %f", time.time() - start)
    start = time.time()
    decode(compresed_huffman, decompresed_huffman, n)
    print("huffman decode time %f", time.time() - start)
    print("compresion ratio: %f", 100 * (1 - os.path.getsize(compresed_huffman) / os.path.getsize(decompresed_huffman)))
    alphabet = {}
    for l in data:
        if l not in alphabet:
            alphabet[l] = 1
    print("Adaptive:")
    start = time.time()
    n = adaptive_hufman(data, compresed_adaptive, alphabet)
    print("addaptive encode time %f", time.time() - start)
    start = time.time()
    adaptive_hufman_decode(compresed_adaptive, decompresed_adaptive, alphabet, n)
    print("addaptive decode time %f", time.time() - start)
    print("compresion ratio: %f",
          100 * (1 - os.path.getsize(compresed_adaptive) / os.path.getsize(decompresed_adaptive)))
    print()


test("data1kb.txt")
test("data10kb.txt")
test("data100kb.txt")
test("data1mb.txt")
test("source.txt")
